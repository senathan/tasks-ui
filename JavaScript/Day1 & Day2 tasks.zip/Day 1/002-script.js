
console.log('I am from script 2')
// 


a=10
b=20
c = a+b
console.log(a+b);

console.log('Total',c);
console.log('Total'+ c);

user_name="Dive"
console.log(typeof c);
console.log(typeof user_name); 

// arithmetic operators
console.log('Addition', a+b);
console.log('Subration', a-b);
console.log('Multiplication', a*b);
console.log('Division', a/b);
console.log('Modulus', a%b);
console.log('Floor', Math.floor(a/b));
console.log('Ciel', Math.ceil(a/b));
console.log('Round', Math.round(a/b));
/*

Round
12.2 => 12 12.6=> 13

Floor
12.2 => 12  12.6 => 12

ceil
12.2 => 13 12.6 => 13

*/