a=10
console.log(a)


//var let const

var name="Siva"; //variable redeclaration 

console.log('Welcome', name) 

var name = 'Kartik'

console.log('Welcome', name)


let user = "Ramesh"

console.log('New User', user)

user = "Usha"


console.log('New User', user)


const y  = 200;

console.log(y)

y =2434234;
console.log(y)



/**
 * 
 * Desc                     var     let     const
 * 
 * 1.Redeclaration          Yes     No      No
 * 2.ReAssignment           Yes     Yes     No
 * 3.Scope-Global           Yes     No      No
 * 
 * 
 */